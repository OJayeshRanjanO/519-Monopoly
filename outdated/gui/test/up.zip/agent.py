class Agent(object):
	def __init__(self, dirPath):
		self.dir = dirPath

	def function2(self):
		print("This function is running from dir: " + self.dir)

